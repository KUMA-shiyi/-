import sys
import threading
import time
import re
import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, colorchooser
from pynput import keyboard
from pynput.keyboard import Key, Listener
import ctypes  # 用于系统级操作（Windows）

class CrossPlatformInputMethod:
    def __init__(self):
        self.article_content = ""
        self.words = []
        self.current_index = 0
        self.current_word = ""
        self.listener = None
        self.running = False
        self.suggestion_window = None
        self.input_history = []
        self.error_word = None
        self.restart_listener = None
        self.tk_root = None
        self.main_window = None
        self.esc_press_count = 0
        self.last_esc_time = 0
        self.ESC_TIMEOUT = 2  # 两次Esc有效时间窗口（秒）
        self.INACTIVITY_TIMEOUT = 300  # 暂停后无操作自动退出时间（5分钟=300秒）
        self.inactivity_timer = None  # 无操作定时器
        self.default_text = "点击文本框添加默写内容，按Esc键可暂停，再次按Esc键退出（或五分钟无操作），按F1键继续。输入完成后按Ctrl+Enter开始默写。"
        
        # 提示框可配置属性（默认值）
        self.suggestion_width = 220  # 提示框宽度
        self.suggestion_height = 30  # 提示框高度
        self.font_size = 12  # 字体大小
        self.font_color = "#ffffff"  # 字体颜色（默认白色）
        self.bg_color = "#000000"  # 背景颜色（默认黑色）
        self.window_position = "左下角"  # 位置：左下角/左上角/正中间底部/右下角/右上角
        
        # 设置界面相关
        self.settings_window = None  # 设置窗口
        self.settings_open = False  # 设置界面状态（打开/关闭）
        
        # 提升进程优先级（仅限Windows系统）
        self._set_process_priority()

    def _set_process_priority(self):
        """提升当前进程优先级（仅Windows有效）"""
        try:
            if sys.platform.startswith('win32'):
                handle = ctypes.windll.kernel32.GetCurrentProcess()
                ctypes.windll.kernel32.SetPriorityClass(handle, 0x00000080)  # HIGH_PRIORITY_CLASS
                print("已提升进程优先级")
        except Exception as e:
            print(f"提升进程优先级失败: {e}")

    def _set_window_topmost(self, window):
        """设置窗口为最顶层，增强显示优先级"""
        try:
            window.attributes('-topmost', True)
            if sys.platform.startswith('win32'):
                hwnd = ctypes.windll.user32.GetParent(window.winfo_id())
                ctypes.windll.user32.SetWindowPos(
                    hwnd, -1, 0, 0, 0, 0,
                    0x0002 | 0x0001 | 0x0004  # SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW
                )
        except Exception as e:
            print(f"设置窗口优先级失败: {e}")

    def set_article_content(self, content):
        self.article_content = content
        self.words = self._intelligent_tokenize(content)
        self.current_index = 0
        self.error_word = None

    def _intelligent_tokenize(self, text):
        text = re.sub(r'\s+', ' ', text).strip()
        pattern = r'([\u4e00-\u9fa5]+)|([a-zA-Z0-9]+)|([^\u4e00-\u9fa5a-zA-Z0-9\s])'
        tokens = re.findall(pattern, text)
        
        result = []
        for token in tokens:
            for t in token:
                if t:
                    result.append(t)
                    break
        return result

    def calculate_window_position(self, window):
        """根据选择的位置计算窗口坐标"""
        screen_width = window.winfo_screenwidth()
        screen_height = window.winfo_screenheight()
        window_width = self.suggestion_width
        window_height = self.suggestion_height
        x, y = 0, 0
        
        if self.window_position == "左下角":
            x = 10
            y = screen_height - window_height - 10
        elif self.window_position == "左上角":
            x = 10
            y = 10
        elif self.window_position == "正中间底部":
            x = (screen_width - window_width) // 2
            y = screen_height - window_height - 10
        elif self.window_position == "右下角":
            x = screen_width - window_width - 10
            y = screen_height - window_height - 10
        elif self.window_position == "右上角":
            x = screen_width - window_width - 10
            y = 10
        
        return x, y

    def create_suggestion_window(self):
        """创建/更新悬浮提示窗口（应用当前配置）"""
        if self.suggestion_window:
            self.suggestion_window.destroy()

        self.suggestion_window = tk.Toplevel(self.tk_root)
        self.suggestion_window.overrideredirect(True)
        self._set_window_topmost(self.suggestion_window)
        self.suggestion_window.attributes('-alpha', 0.9)
        self.suggestion_window.config(bg=self.bg_color)  # 应用背景色
        self.suggestion_window.geometry(f"{self.suggestion_width}x{self.suggestion_height}")  # 应用尺寸

        self.suggestion_window.attributes('-toolwindow', True)

        # 应用字体大小和颜色
        self.suggestion_text = tk.Text(
            self.suggestion_window,
            bg=self.bg_color,
            fg=self.font_color,
            font=("SimHei", self.font_size),
            padx=3,
            pady=3,
            relief=tk.FLAT,
            bd=0,
            highlightthickness=0,
            selectbackground=self.bg_color,
            inactiveselectbackground=self.bg_color,
            wrap=tk.NONE,
            height=1,
            width=int(self.suggestion_width // (self.font_size * 0.6))  # 自适应宽度的文本框
        )
        self.suggestion_text.pack(fill=tk.X, side=tk.LEFT)
        self.suggestion_text.config(state=tk.DISABLED)
        self.suggestion_text.tag_configure("error", foreground="#ff0000")  # 错误文本颜色固定为红色

    def show_suggestion(self, suggestions):
        try:
            if not self.suggestion_window or not self.suggestion_window.winfo_exists():
                self.create_suggestion_window()

            self.suggestion_text.config(state=tk.NORMAL)
            self.suggestion_text.delete(1.0, tk.END)

            if self.error_word:
                self.suggestion_text.insert(tk.END, self.error_word, "error")
                self.suggestion_text.insert(tk.END, f" → {suggestions[0]}")
            else:
                display_text = " ".join(suggestions) if suggestions else "END"
                self.suggestion_text.insert(tk.END, display_text)

            self.suggestion_text.config(state=tk.DISABLED)

            # 应用配置的位置
            x, y = self.calculate_window_position(self.suggestion_window)
            self.suggestion_window.geometry(f"+{x}+{y}")
            self.suggestion_window.deiconify()

        except Exception as e:
            print(f"显示提示错误: {e}")

    def get_current_suggestions(self):
        if len(self.input_history) == 0:
            if self.current_index < len(self.words):
                return [self.words[self.current_index]]
            return []
        
        remaining = len(self.words) - self.current_index
        if remaining >= 2:
            return self.words[self.current_index:self.current_index+2]
        elif remaining == 1:
            return [self.words[self.current_index]]
        else:
            return ["END"]

    def open_settings_window(self):
        """打开设置界面"""
        if self.settings_open:
            return
        
        self.settings_open = True
        self.settings_window = tk.Toplevel(self.tk_root)
        self.settings_window.title("提示框设置")
        self.settings_window.geometry("400x500")
        self.settings_window.resizable(False, False)
        self._set_window_topmost(self.settings_window)
        
        # 居中显示
        self.settings_window.update_idletasks()
        width = self.settings_window.winfo_width()
        height = self.settings_window.winfo_height()
        x = (self.settings_window.winfo_screenwidth() // 2) - (width // 2)
        y = (self.settings_window.winfo_screenheight() // 2) - (height // 2)
        self.settings_window.geometry(f"+{x}+{y}")

        # 1. 尺寸设置
        size_frame = ttk.LabelFrame(self.settings_window, text="提示框尺寸", padding=10)
        size_frame.pack(fill=tk.X, padx=20, pady=10)
        
        ttk.Label(size_frame, text="宽度:").grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
        self.width_var = tk.StringVar(value=str(self.suggestion_width))
        width_entry = ttk.Entry(size_frame, textvariable=self.width_var, width=10)
        width_entry.grid(row=0, column=1, padx=5, pady=5)
        ttk.Label(size_frame, text="像素").grid(row=0, column=2, padx=5, pady=5)

        ttk.Label(size_frame, text="高度:").grid(row=0, column=3, padx=5, pady=5, sticky=tk.W)
        self.height_var = tk.StringVar(value=str(self.suggestion_height))
        height_entry = ttk.Entry(size_frame, textvariable=self.height_var, width=10)
        height_entry.grid(row=0, column=4, padx=5, pady=5)
        ttk.Label(size_frame, text="像素").grid(row=0, column=5, padx=5, pady=5)

        # 2. 字体设置
        font_frame = ttk.LabelFrame(self.settings_window, text="字体设置", padding=10)
        font_frame.pack(fill=tk.X, padx=20, pady=10)
        
        ttk.Label(font_frame, text="字体大小:").grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
        self.font_size_var = tk.StringVar(value=str(self.font_size))
        font_size_entry = ttk.Entry(font_frame, textvariable=self.font_size_var, width=10)
        font_size_entry.grid(row=0, column=1, padx=5, pady=5)
        ttk.Label(font_frame, text="号").grid(row=0, column=2, padx=5, pady=5)

        # 3. 颜色设置
        color_frame = ttk.LabelFrame(self.settings_window, text="颜色设置", padding=10)
        color_frame.pack(fill=tk.X, padx=20, pady=10)
        
        # 字体颜色
        self.font_color_var = tk.StringVar(value=self.font_color)
        ttk.Label(color_frame, text="字体颜色:").grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
        font_color_btn = ttk.Button(color_frame, text="选择颜色", command=self.choose_font_color)
        font_color_btn.grid(row=0, column=1, padx=5, pady=5)
        self.font_color_label = ttk.Label(color_frame, text=self.font_color, background=self.font_color, foreground="white")
        self.font_color_label.grid(row=0, column=2, padx=5, pady=5, width=10)

        # 背景颜色
        self.bg_color_var = tk.StringVar(value=self.bg_color)
        ttk.Label(color_frame, text="背景颜色:").grid(row=0, column=3, padx=5, pady=5, sticky=tk.W)
        bg_color_btn = ttk.Button(color_frame, text="选择颜色", command=self.choose_bg_color)
        bg_color_btn.grid(row=0, column=4, padx=5, pady=5)
        self.bg_color_label = ttk.Label(color_frame, text=self.bg_color, background=self.bg_color, foreground="white")
        self.bg_color_label.grid(row=0, column=5, padx=5, pady=5, width=10)

        # 4. 位置设置
        pos_frame = ttk.LabelFrame(self.settings_window, text="显示位置", padding=10)
        pos_frame.pack(fill=tk.X, padx=20, pady=10)
        
        self.pos_var = tk.StringVar(value=self.window_position)
        positions = ["左下角", "左上角", "正中间底部", "右下角", "右上角"]
        for i, pos in enumerate(positions):
            ttk.Radiobutton(pos_frame, text=pos, variable=self.pos_var, value=pos).grid(row=0, column=i, padx=5, pady=5)

        # 5. 应用按钮
        apply_btn = ttk.Button(self.settings_window, text="应用设置", command=self.apply_settings)
        apply_btn.pack(pady=20)

        # 窗口关闭事件
        self.settings_window.protocol("WM_DELETE_WINDOW", self.close_settings_window)

    def choose_font_color(self):
        """选择字体颜色"""
        color = colorchooser.askcolor(title="选择字体颜色", initialcolor=self.font_color_var.get())
        if color[1]:  # 选择了有效颜色
            self.font_color_var.set(color[1])
            self.font_color_label.config(text=color[1], background=color[1])

    def choose_bg_color(self):
        """选择背景颜色"""
        color = colorchooser.askcolor(title="选择背景颜色", initialcolor=self.bg_color_var.get())
        if color[1]:  # 选择了有效颜色
            self.bg_color_var.set(color[1])
            self.bg_color_label.config(text=color[1], background=color[1])

    def apply_settings(self):
        """应用设置并更新提示框"""
        try:
            # 验证并更新尺寸（必须为正整数）
            new_width = int(self.width_var.get())
            new_height = int(self.height_var.get())
            if new_width <= 0 or new_height <= 0:
                raise ValueError("尺寸必须为正整数")
            self.suggestion_width = new_width
            self.suggestion_height = new_height

            # 验证并更新字体大小（必须为正整数）
            new_font_size = int(self.font_size_var.get())
            if new_font_size <= 0:
                raise ValueError("字体大小必须为正整数")
            self.font_size = new_font_size

            # 更新颜色和位置
            self.font_color = self.font_color_var.get()
            self.bg_color = self.bg_color_var.get()
            self.window_position = self.pos_var.get()

            # 重新创建提示框以应用新设置
            if self.suggestion_window and self.suggestion_window.winfo_exists():
                self.create_suggestion_window()
                # 重新显示当前提示内容
                suggestions = self.get_current_suggestions()
                self.show_suggestion(suggestions)

            messagebox.showinfo("成功", "设置已应用！")
        except ValueError as e:
            messagebox.showerror("错误", f"输入无效：{str(e)}")

    def close_settings_window(self):
        """关闭设置界面"""
        self.settings_open = False
        if self.settings_window and self.settings_window.winfo_exists():
            self.settings_window.destroy()
        self.settings_window = None

    def toggle_settings(self):
        """切换设置界面显示/隐藏（F2快捷键）"""
        if self.settings_open:
            self.close_settings_window()
            print("设置界面已关闭")
        else:
            self.open_settings_window()
            print("设置界面已打开（按F2可关闭）")

    def on_press(self, key):
        try:
            # 新增F2快捷键处理
            if key == Key.f2:
                # 在主线程中处理UI操作（避免线程冲突）
                self.tk_root.after(0, self.toggle_settings)
                return
            
            if key == Key.esc:
                current_time = time.time()
                if self.esc_press_count >= 1 and current_time - self.last_esc_time < self.ESC_TIMEOUT:
                    print("检测到两次Esc，程序退出")
                    self.stop_global_listener()
                    return False
                else:
                    self.esc_press_count += 1
                    self.last_esc_time = current_time
                    threading.Timer(self.ESC_TIMEOUT, self.reset_esc_count).start()
                    self.pause_listener()
                    return False
            
            if hasattr(key, 'char') and key.char is not None:
                self.current_word += key.char

            elif key == Key.space:
                if self.current_word.strip():
                    input_word = self.current_word.strip()
                    if self.current_index < len(self.words):
                        correct_word = self.words[self.current_index]
                        
                        if input_word == correct_word:
                            self.input_history.append(input_word)
                            self.current_index += 1
                            self.error_word = None
                        else:
                            self.error_word = input_word
                    
                    suggestions = self.get_current_suggestions()
                    self.show_suggestion(suggestions)
                
                self.current_word = ""

            elif key == Key.backspace:
                self.current_word = self.current_word[:-1]

        except Exception as e:
            print(f"按键处理错误: {e}")

    def reset_esc_count(self):
        self.esc_press_count = 0

    def start_inactivity_timer(self):
        """启动无操作定时器，5分钟后自动退出"""
        self.cancel_inactivity_timer()
        self.inactivity_timer = threading.Timer(
            self.INACTIVITY_TIMEOUT, 
            self.auto_exit_due_to_inactivity
        )
        self.inactivity_timer.daemon = True
        self.inactivity_timer.start()
        print(f"暂停模式：将在{self.INACTIVITY_TIMEOUT//60}分钟后自动退出")

    def cancel_inactivity_timer(self):
        """取消无操作定时器"""
        if self.inactivity_timer:
            self.inactivity_timer.cancel()
            self.inactivity_timer = None

    def auto_exit_due_to_inactivity(self):
        """因长时间无操作自动退出"""
        print(f"暂停后{self.INACTIVITY_TIMEOUT//60}分钟无操作，程序自动退出")
        self.stop_global_listener()

    def start_global_listener(self):
        try:
            self.cancel_inactivity_timer()
            self.esc_press_count = 0
            self.last_esc_time = 0
            
            self.running = True
            suggestions = self.get_current_suggestions()
            if suggestions:
                self.show_suggestion(suggestions)

            self.listener_thread = threading.Thread(target=self._run_listener)
            self.listener_thread.daemon = True
            self.listener_thread.start()

        except Exception as e:
            print(f"启动监听错误: {e}")

    def _run_listener(self):
        self.listener = Listener(on_press=self.on_press)
        self.listener.start()
        print("程序已启动，按Esc暂停，2秒内再按一次Esc退出，按F1重启，按F2打开设置")
        self.listener.join()

    def pause_listener(self):
        self.running = False
        if self.listener:
            self.listener.stop()
        if self.suggestion_window and self.suggestion_window.winfo_exists():
            self.suggestion_window.destroy()
        self.suggestion_window = None
        print("程序已暂停，2秒内再按一次Esc退出，按F1继续，按F2打开设置")
        
        self.start_inactivity_timer()
        self.restart_thread = threading.Thread(target=self._run_restart_listener)
        self.restart_thread.daemon = True
        self.restart_thread.start()

    def _run_restart_listener(self):
        def on_restart_press(key):
            if key == Key.f2:
                self.tk_root.after(0, self.toggle_settings)
                return
            if key == Key.esc:
                print("检测到两次Esc，程序退出")
                self.cancel_inactivity_timer()
                if self.restart_listener:
                    self.restart_listener.stop()
                self.stop_global_listener()
                return False
            elif key == Key.f1:
                self.esc_press_count = 0
                self.cancel_inactivity_timer()
                print("继续之前的进程...")
                if self.restart_listener:
                    self.restart_listener.stop()
                self.start_global_listener()
                return False

        self.restart_listener = Listener(on_press=on_restart_press)
        self.restart_listener.start()
        self.restart_listener.join()

    def stop_global_listener(self):
        self.cancel_inactivity_timer()
        self.close_settings_window()  # 退出时关闭设置界面
        
        self.running = False
        if self.listener:
            self.listener.stop()
        if self.restart_listener:
            self.restart_listener.stop()
        if self.suggestion_window and self.suggestion_window.winfo_exists():
            self.suggestion_window.destroy()
        if self.main_window and self.main_window.winfo_exists():
            self.main_window.destroy()
        if self.tk_root and self.tk_root.winfo_exists():
            self.tk_root.destroy()
        print("程序已完全退出")
        sys.exit(0)

    def create_loading_screen(self):
        loading_window = tk.Toplevel(self.tk_root)
        loading_window.title("加载中")
        loading_window.geometry("400x200")
        loading_window.resizable(False, False)
        self._set_window_topmost(loading_window)
        
        loading_window.update_idletasks()
        width = loading_window.winfo_width()
        height = loading_window.winfo_height()
        x = (loading_window.winfo_screenwidth() // 2) - (width // 2)
        y = (loading_window.winfo_screenheight() // 2) - (height // 2)
        loading_window.geometry('{}x{}+{}+{}'.format(width, height, x, y))
        
        tk.Label(loading_window, text="默写提示器", font=("SimHei", 18)).pack(pady=20)
        
        progress_frame = ttk.Frame(loading_window, width=300, height=30)
        progress_frame.pack(pady=20)
        
        progress_var = tk.DoubleVar()
        progress_bar = ttk.Progressbar(
            progress_frame,
            variable=progress_var,
            length=300,
            mode='determinate'
        )
        progress_bar.pack(fill=tk.X)
        
        status_label = tk.Label(loading_window, text="准备中...", font=("SimHei", 10))
        status_label.pack(pady=10)
        
        loading_window.update()
        
        for i in range(101):
            progress_var.set(i)
            status_label.config(text=f"加载中... {i}%")
            loading_window.update()
            time.sleep(0.02)
            
        loading_window.destroy()
        self.create_input_dialog()

    def create_input_dialog(self):
        self.main_window = tk.Toplevel(self.tk_root)
        self.main_window.title("默写提示器 - 输入文本")
        self.main_window.geometry("600x400")
        self.main_window.resizable(True, True)
        self._set_window_topmost(self.main_window)
        
        self.main_window.update_idletasks()
        width = self.main_window.winfo_width()
        height = self.main_window.winfo_height()
        x = (self.main_window.winfo_screenwidth() // 2) - (width // 2)
        y = (self.main_window.winfo_screenheight() // 2) - (height // 2)
        self.main_window.geometry('{}x{}+{}+{}'.format(width, height, x, y))
        
        tk.Label(self.main_window, text="请输入要默写的内容（按Ctrl+Enter开始）:", font=("SimHei", 12)).pack(pady=10, padx=10, anchor=tk.W)
        
        self.text_input = scrolledtext.ScrolledText(
            self.main_window,
            font=("SimHei", 12),
            wrap=tk.WORD,
            width=60,
            height=12
        )
        self.text_input.pack(pady=10, padx=10, fill=tk.BOTH, expand=True)
        
        self.text_input.insert(tk.END, self.default_text)
        self.text_input.tag_add("default", "1.0", "end")
        self.text_input.tag_config("default", foreground="#999999")
        self.text_input.focus_set()
        
        def clear_default_text(event):
            current_content = self.text_input.get("1.0", "end-1c")
            if current_content == self.default_text:
                self.text_input.delete("1.0", tk.END)
                self.text_input.tag_config("default", foreground="#000000")
        
        self.text_input.bind('<Button-1>', clear_default_text)
        self.text_input.bind('<FocusIn>', clear_default_text)
        self.text_input.bind('<Control-Return>', self.start_application)
        
        tk.Button(
            self.main_window,
            text="开始默写",
            command=self.start_application,
            font=("SimHei", 12),
            width=15,
            height=1
        ).pack(pady=10)

    def start_application(self, event=None):
        content = self.text_input.get(1.0, tk.END).strip()
        if not content or content == self.default_text:
            messagebox.showwarning("警告", "请输入内容！")
            return
            
        self.set_article_content(content)
        self.main_window.destroy()
        threading.Thread(target=self.start_global_listener, daemon=True).start()

    def run(self):
        self.tk_root = tk.Tk()
        self.tk_root.withdraw()
        self.create_loading_screen()
        self.tk_root.mainloop()

def main():
    try:
        app = CrossPlatformInputMethod()
        app.run()
    except Exception as e:
        print(f"程序错误: {e}")

if __name__ == "__main__":
    main()